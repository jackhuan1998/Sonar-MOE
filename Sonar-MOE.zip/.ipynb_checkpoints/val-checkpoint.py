from ultralytics import YOLO
import multiprocessing
def worker():
    # wget https://github.com/THU-MIG/yolov10/releases/download/v1.1/yolov10{n/s/m/b/l/x}.pt
    model = YOLO('/root/lanyun-tmp/26New/Code/YOLO-Master-main/runs/tjck_exp/317_master_v0_top1/weights/best.pt')
    metrics=model.val(data='/root/lanyun-tmp/26New/Code/YOLO-Master-main/datasets/tjck_coco/data.yaml', batch=6)
    print(metrics.box.maps)

if __name__ == "__main__":
    # 使用多进程时，在 Windows 下需要在 __main__ 下运行

    multiprocessing.freeze_support()  # Windows 特有，防止冻结支持错误
    process = multiprocessing.Process(target=worker)
    process.start()
    process.join()