from ultralytics import YOLO


#yolov9c-seg.yaml
if __name__ == '__main__':
    # Load a model
    model = YOLO('cfg/models/master/v0/seg/yolo-master-seg-n.yaml')  # 从 YAML 构建新模型
    model = model.float()  # 添加这一行
    # Train the model
    train_results = model.train(
        data="/root/lanyun-tmp/26New/Code/YOLO-Master-main/datasets/tjck_coco/data.yaml",  # path to dataset YAML lanyun-tmp/26New/Code/YOLO-Master-main/datasets/sctd_coco
        epochs=200,  # number of training epochs
        imgsz=640,  # training image size
        batch=8,
        device="0", 
        project="runs/tjck_exp",   # 自定义大文件夹
        name="tjck_Global_new_Local_new_0.001_top1",  # 本次实验名
    )